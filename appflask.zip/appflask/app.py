from flask import Flask, request, render_template
import pickle
import string

app = Flask(__name__)

@app.route('/')
def hello_world():
	return 'Hello, World!'

@app.route('/index', methods=['POST', 'GET'])
def fetch_tweet():
	if request.method == "POST":
		tweet = request.form['tweet']
		return redirect(url_for('classify', tweet=tweet))
	return render_template("index.html")

@app.route('/classify', methods=['GET'])
def classify():    
    tweet = request.args.get('tweet')  
    pred = model.predict([tweet])
    if pred[0] == 0:
    	kelas = 'Bukan Keluhan/Respon'
    elif pred[0] == 1:
    	kelas = 'Keluhan'
    else:
    	kelas = 'Respon'
    return render_template("index.html", tweet=tweet, kelas=kelas)

if __name__=="__main__":
	def tokenize(msg):
		clean = [char for char in msg if char not in string.punctuation]
		clean = ''.join(clean)
		return clean.lower().split()

	model = pickle.load(open('model.pkl','rb'))
	app.run(debug=True, port=8080)